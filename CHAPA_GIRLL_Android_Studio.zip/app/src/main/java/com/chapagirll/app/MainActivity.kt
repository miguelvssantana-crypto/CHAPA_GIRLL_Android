package com.chapagirll.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Pink = Color(0xFFFF1681)
private val Black = Color(0xFF080808)
private val Card = Color(0xFF151515)

data class Product(val name: String, val description: String, val price: Double)

private val products = listOf(
    Product("X-Burger", "Pão, hambúrguer 180g, queijo, alface, tomate e molho especial.", 24.90),
    Product("Chapa Bacon", "Hambúrguer 180g, bacon, cheddar e molho especial.", 27.90),
    Product("Smash Duplo", "Dois smash, queijo, cebola, picles e molho.", 28.90),
    Product("Cheddar Melt", "Hambúrguer 180g, cheddar cremoso e cebola caramelizada.", 26.90)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChapaGirllApp() }
    }
}

@Composable
fun ChapaGirllApp() {
    var tab by remember { mutableStateOf("home") }
    var cart by remember { mutableStateOf(listOf<Product>()) }
    var checkout by remember { mutableStateOf(false) }
    var orderDone by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pink, background = Black, surface = Card,
            onPrimary = Color.White, onBackground = Color.White
        )
    ) {
        Scaffold(
            containerColor = Black,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().height(64.dp).background(Black)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("☰", fontSize = 24.sp)
                    Text("CHAPA GIRLL", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Pink)
                    Text("♡", fontSize = 25.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101010)) {
                    listOf("home" to "⌂", "menu" to "▣", "orders" to "▤", "account" to "♙").forEach {
                        NavigationBarItem(
                            selected = tab == it.first,
                            onClick = { tab = it.first; checkout = false },
                            icon = { Text(it.second, fontSize = 20.sp) },
                            label = { Text(when(it.first) {
                                "home" -> "Início"; "menu" -> "Cardápio"; "orders" -> "Pedidos"; else -> "Conta"
                            }) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Pink, selectedTextColor = Pink,
                                indicatorColor = Color.Transparent
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    checkout -> CheckoutScreen(
                        onBack = { checkout = false },
                        onDone = { cart = emptyList(); checkout = false; orderDone = true; tab = "orders" }
                    )
                    tab == "home" -> HomeScreen(onMenu = { tab = "menu" }, onAdd = { cart = cart + it })
                    tab == "menu" -> MenuScreen(cartCount = cart.size, onAdd = { cart = cart + it }, onCart = { checkout = true })
                    tab == "orders" -> OrdersScreen(orderDone)
                    else -> AccountScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onMenu: () -> Unit, onAdd: (Product) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF200914)) {
                Column(Modifier.padding(22.dp)) {
                    Text("🔥 OFERTA DA CHAPA", color = Pink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("O sabor fala mais alto.", fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("Peça seus favoritos da CHAPA GIRLL.", color = Color.LightGray)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = onMenu, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Pink)) {
                        Text("FAZER PEDIDO", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Text("Categorias", fontSize = 19.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Category("🍔", "Hambúrgueres"); Category("🍟", "Combos")
            }
        }
        item { Text("Mais pedidos", fontSize = 19.sp, fontWeight = FontWeight.Bold) }
        items(products.take(2)) { ProductCard(it, onAdd) }
    }
}

@Composable
fun Category(icon: String, name: String) {
    Surface(Modifier.weight(1f), shape = RoundedCornerShape(12.dp), color = Card) {
        Column(Modifier.padding(18.dp)) { Text(icon, fontSize = 30.sp); Text(name, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun MenuScreen(cartCount: Int, onAdd: (Product) -> Unit, onCart: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Cardápio", fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("🛒 $cartCount", color = Pink, modifier = Modifier.clickable { onCart() })
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(products) { ProductCard(it, onAdd) }
        }
    }
}

@Composable
fun ProductCard(p: Product, onAdd: (Product) -> Unit) {
    Surface(shape = RoundedCornerShape(13.dp), color = Card) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(72.dp).background(Color(0xFF29101D), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                Text("🍔", fontSize = 38.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text(p.description, color = Color.LightGray, fontSize = 12.sp)
                Text("R$ %.2f".format(p.price).replace(".", ","), color = Pink, fontWeight = FontWeight.Bold)
            }
            Button(onClick = { onAdd(p) }, shape = RoundedCornerShape(50), contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(42.dp), colors = ButtonDefaults.buttonColors(Pink)) { Text("+", fontSize = 20.sp) }
        }
    }
}

@Composable
fun CheckoutScreen(onBack: () -> Unit, onDone: () -> Unit) {
    var delivery by remember { mutableStateOf(true) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Finalizar pedido", fontSize = 24.sp, fontWeight = FontWeight.Black) }
        item {
            Surface(shape = RoundedCornerShape(13.dp), color = Card) {
                Column(Modifier.padding(14.dp)) {
                    Text("Como você quer receber?", fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth().clickable { delivery = true }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(delivery, { delivery = true }); Text("🚴  Entrega — receber em casa")
                    }
                    Row(Modifier.fillMaxWidth().clickable { delivery = false }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(!delivery, { delivery = false }); Text("🛍️  Retirada na loja")
                    }
                }
            }
        }
        if (delivery) {
            item {
                Surface(shape = RoundedCornerShape(13.dp), color = Card) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Endereço de entrega", fontWeight = FontWeight.Bold)
                        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Rua e número") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Bairro") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Complemento") }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
        item {
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Pink)) {
                Text("CONFIRMAR PEDIDO", fontWeight = FontWeight.Bold)
            }
        }
        item { Text("← Voltar", modifier = Modifier.clickable { onBack() }, color = Pink) }
    }
}

@Composable
fun OrdersScreen(done: Boolean) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Pedidos", fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp))
        Surface(shape = RoundedCornerShape(13.dp), color = Card) {
            Column(Modifier.padding(16.dp)) {
                Text(if (done) "🔥 Pedido recebido!" else "Nenhum pedido recente", color = Pink, fontWeight = FontWeight.Bold)
                if (done) {
                    Text("Pedido #1234", fontWeight = FontWeight.Bold)
                    Text("✓ Pedido recebido\n✓ Preparando\n○ Aguardando andamento", color = Color.LightGray)
                } else Text("Faça seu primeiro pedido pelo cardápio.", color = Color.LightGray)
            }
        }
    }
}

@Composable
fun AccountScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Minha conta", fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp))
        Surface(shape = RoundedCornerShape(13.dp), color = Card) {
            Column(Modifier.padding(16.dp)) {
                Text("👤 Bem-vindo à CHAPA GIRLL!", fontWeight = FontWeight.Bold)
                Text("Crie sua conta para salvar endereços e acompanhar pedidos.", color = Color.LightGray)
                Spacer(Modifier.height(12.dp))
                Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Pink)) { Text("ENTRAR") }
                OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("CRIAR CONTA") }
            }
        }
    }
}
